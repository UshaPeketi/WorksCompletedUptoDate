import { Component, OnInit, ViewChild } from '@angular/core';
import { UserService } from '../services/user.service';
import { Contact } from '../models/Contact';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  @ViewChild("f") form: NgForm;
  // form conatins the name of the Contact and mobile number
  // form: any = {};
  // contacts is to store all Contacts data
  contacts: Contact[] = [];
  // message is to display message
  message;
  //contactObj: Contact = new Contact();

  // isContactedAdded is for validating contact is added or not
  isContactedAdded: boolean;
  constructor(private userservice: UserService) { }
  // Call UserService and use getAllContacts method to get Contacts data
  ngOnInit() {
    this.userservice.getAllContacts().subscribe(
      data => {
        this.contacts = data;
      });
  }
  // Write logic to add a Contact by using addContact method of UserService
  // Display message 'Contact already exists' if already a contact exists with same mobile number
  // Display message 'Failed to add Contact' while error handling
  // Display message 'Contact Added' if contact is added


  onSubmit() {
    for (let i = 0; i < this.contacts.length; i++) {
      if ((this.form.value.mobile) == (this.contacts[i].mobile)) {
        this.message = "Contact already exists";
        this.isContactedAdded = true;
        this.getAllContacts();
        return;
      }
    }

    this.userservice.addcontact(this.form.value)
      .subscribe(res => {
        this.message = "Contact added";
        this.isContactedAdded = true;
        this.getAllContacts();
      },
        err => {
          alert("something went wrong");
          this.message = "Failed to add Contact";
          this.isContactedAdded = false;

        })
    this.form.resetForm();
  }

  getAllContacts() {
    this.userservice.getAllContacts()
      .subscribe(data => {
        this.contacts = data;
      })
  }

}