// Data model for Contact Entity
export class Contact {
    name?: String;
    mobile?: number;
}
