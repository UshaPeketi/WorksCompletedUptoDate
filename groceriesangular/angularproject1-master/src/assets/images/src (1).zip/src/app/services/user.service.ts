import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Contact } from '../models/Contact';
import { catchError, map } from 'rxjs/operators'
import { Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private baseUrl: string = "http://localhost:3000";

  constructor(private http: HttpClient) {
  }

  // Implement addContacts method using HttpClient for a saving a Contacts details
  addcontact(data: any): Observable<any> {
    let dataUrl: string = `${this.baseUrl}/contacts`;
    return this.http.post<Contact>(dataUrl, data).pipe(catchError(this.handleError))
  }

  // Implement getAllContactss method using HttpClient for getting all Contacts details
  public getAllContacts(): Observable<any> {
    let dataUrl: string = `${this.baseUrl}/contacts`;
    return this.http.get<any>(dataUrl).pipe(catchError(this.handleError))
  }

  public handleError(error: HttpErrorResponse) {
    let errorMessage: string = ''
    if (error.error instanceof ErrorEvent) {
      //client Error
      errorMessage = `Error :${error.error.message}`
    } else {
      //server side error
      errorMessage = `Status: ${error.status} \n Message: ${error.message}`;
    }
    return throwError(error.message)
  }

}

